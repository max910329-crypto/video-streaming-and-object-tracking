# dataset.py
import os
import csv
import ast
import cv2
import numpy as np
import torch
from torch.utils.data import Dataset

import albumentations as A
from albumentations.pytorch import ToTensorV2

# CLIP normalization
CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD  = (0.26862954, 0.26130258, 0.27577711)

def polygon_to_mask(seg_str, h, w):
    """
    seg_str: like "[x1, y1, x2, y2, ...]" in ORIGINAL image coords.
    return mask uint8 (h,w) with {0,1}
    """
    seg_str = (seg_str or "").strip()
    mask = np.zeros((h, w), dtype=np.uint8)
    if seg_str in ("", "[]"):
        return mask

    try:
        pts = ast.literal_eval(seg_str)
        if not isinstance(pts, list) or len(pts) < 6 or (len(pts) % 2 != 0):
            return mask
        pts = np.array(pts, dtype=np.float32).reshape(-1, 2)
        if pts.shape[0] < 3:
            return mask
    except Exception:
        return mask

    pts[:, 0] = np.clip(pts[:, 0], 0, w - 1)
    pts[:, 1] = np.clip(pts[:, 1], 0, h - 1)
    pts_int = pts.astype(np.int32).reshape(-1, 1, 2)
    cv2.fillPoly(mask, [pts_int], 1)
    return mask

def get_train_aug(image_size):
    return A.Compose([
        # 不要 RandomResizedCrop，改成穩定 resize
        A.Resize(height=image_size, width=image_size),

        # 只做「不改語意」的影像外觀增強
        A.ColorJitter(brightness=0.15, contrast=0.15, saturation=0.12, hue=0.05, p=0.6),

        # 二選一即可，不要全開太猛
        # A.GaussNoise(var_limit=(5.0, 20.0), p=0.20),
        A.GaussianBlur(blur_limit=(3, 3), p=0.10),

        # 可選：讓光照更耐受（通常安全）
        # A.CLAHE(clip_limit=2.0, tile_grid_size=(8, 8), p=0.05),

        A.Normalize(mean=CLIP_MEAN, std=CLIP_STD, max_pixel_value=255.0),
        ToTensorV2(),
    ])

def get_val_aug(image_size):
    return A.Compose([
        A.Resize(image_size, image_size),
        A.Normalize(mean=CLIP_MEAN, std=CLIP_STD, max_pixel_value=255.0),
        ToTensorV2(),
    ])

class PhraseGroundingDataset(Dataset):
    """
    Train/Val: returns (image_tensor, text, mask_tensor)
    Test:      returns (image_tensor, text, id, image_name)  (return_gt=False)
    """
    def __init__(self, csv_path, img_dir, image_size=224, is_train=False, return_gt=True):
        self.csv_path = csv_path
        self.img_dir = img_dir
        self.image_size = image_size
        self.is_train = is_train
        self.return_gt = return_gt

        self.aug = get_train_aug(image_size) if is_train else get_val_aug(image_size)

        self.rows = []
        with open(csv_path, encoding="utf-8-sig", newline="") as f:
            r = csv.DictReader(f)
            for row in r:
                self.rows.append(row)

        print(f"Loading dataset from {csv_path}...")
        print(f"Loaded {len(self.rows)} samples.")

    def __len__(self):
        return len(self.rows)

    def __getitem__(self, idx):
        row = self.rows[idx]

        # 你們 CSV 常見欄位（必要時你可以改這幾行 key）
        sample_id = str(row.get("id", "")).strip()
        img_name  = (row.get("image") or "").strip()
        text      = (row.get("text") or "").strip()
        seg_str   = (row.get("segmentation") or "").strip()  # train/val 才會有

        img_path = os.path.join(self.img_dir, img_name)
        img_bgr = cv2.imread(img_path)
        if img_bgr is None:
            raise FileNotFoundError(f"Cannot read image: {img_path}")

        img_rgb = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2RGB)
        h, w = img_rgb.shape[:2]

        if self.return_gt:
            mask = polygon_to_mask(seg_str, h, w)  # (h,w) 0/1
        else:
            mask = np.zeros((h, w), dtype=np.uint8)

        out = self.aug(image=img_rgb, mask=mask)
        image_t = out["image"]           # (3,H,W) float32 normalized
        mask_t  = out["mask"].float()    # (H,W) float32 0/1

        if self.return_gt:
            # -> (1,H,W)
            return image_t, text, mask_t.unsqueeze(0)
        else:
            return image_t, text, sample_id, img_name
