import os
import csv
import time
import math
import argparse
from dataclasses import dataclass
import heapq  # <-- NEW

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader

from tqdm import tqdm

from model import CLIPUNet
from dataset import PhraseGroundingDataset
from transformers import CLIPProcessor


# =========================
# 你只需要改這裡的設定
# =========================
@dataclass
class CFG:
    img_dir: str = "data"                 # 你的資料根目錄（裡面有 train_images/val_images 或直接放圖片）
    train_csv: str = "data/train.csv"  # "data/train_split.csv"
    val_csv: str = "data/val.csv"
    holdout_csv: str = "data/holdout.csv"  

    output_dir: str = "checkpoints"
    run_name: str = "w_314605021"

    image_size: int = 224
    batch_size: int = 16    
    num_workers: int = 4                  # 如果你 tokenizers fork 警告很煩，可改 0
    epochs: int = 80

    # Optim
    lr_head: float = 1e-3                 # 你的 decoder/head lr
    lr_clip: float = 2e-5                 # 解凍後 CLIP lr（小）
    weight_decay: float = 1e-4
    grad_clip: float = 1.0

    # Scheduler
    warmup_ratio: float = 0.05            # warmup steps = total_steps * warmup_ratio

    # Loss
    dice_weight: float = 1.0              # loss = BCE + dice_weight*Dice

    # Eval / checkpoint
    thr_eval: float = 0.10                # 用固定閾值做 val IoU（你 find_thr 也可再調）
    freeze_epochs: int = 5                # 前 N 個 epoch freeze CLIP，只訓練 head
    unfreeze_last_blocks: int = 2         # 解凍 vision encoder 最後幾個 transformer blocks（1~2 通常夠）

    # NEW: Top-K checkpoints
    top_k: int = 5                        # <-- NEW: keep top-5 by val_iou


cfg = CFG()


# =========================
# 工具：Dice loss / IoU
# =========================
def dice_loss_with_logits(logits, targets, eps=1e-6):
    # logits: (B,1,H,W), targets: (B,1,H,W) in {0,1}
    probs = torch.sigmoid(logits)
    probs = probs.flatten(1)
    targets = targets.flatten(1)
    inter = (probs * targets).sum(dim=1)
    union = probs.sum(dim=1) + targets.sum(dim=1)
    dice = (2 * inter + eps) / (union + eps)
    return 1 - dice.mean()

@torch.no_grad()
def batch_iou_from_logits(logits, targets, thr=0.10, eps=1e-6):
    # logits/targets: (B,1,H,W)
    pred = (torch.sigmoid(logits) > thr)
    gt = (targets > 0.5)
    inter = (pred & gt).flatten(1).sum(dim=1).float()
    union = (pred | gt).flatten(1).sum(dim=1).float()
    iou = (inter + eps) / (union + eps)
    return iou.mean().item()


# =========================
# 解凍策略：freeze -> unfreeze(last blocks)
# =========================
def set_clip_trainable(model: CLIPUNet, trainable: bool):
    for p in model.clip.parameters():
        p.requires_grad = trainable

def unfreeze_clip_last_blocks(model: CLIPUNet, n_blocks: int = 2):
    """
    只解凍 CLIP vision encoder 最後 n 個 blocks + LayerNorm
    這通常比全解凍穩很多。
    """
    # 先全部 freeze
    set_clip_trainable(model, False)

    # 解凍 layernorm / final norm（名稱可能不同，做寬鬆匹配）
    for name, p in model.clip.named_parameters():
        if ("layernorm" in name.lower()) or ("layer_norm" in name.lower()) or ("ln_" in name.lower()):
            p.requires_grad = True

    # 嘗試抓 vision encoder blocks（HuggingFace CLIP 常見結構）
    try:
        blocks = model.clip.vision_model.encoder.layers
        # 解凍最後 n_blocks
        for blk in blocks[-n_blocks:]:
            for p in blk.parameters():
                p.requires_grad = True
    except Exception:
        # 抓不到就保守不解凍（通常會抓得到）
        pass


def build_optimizer(model: CLIPUNet, lr_head, lr_clip, wd):
    head_params = []
    clip_params = []

    for name, p in model.named_parameters():
        if not p.requires_grad:
            continue
        if name.startswith("clip."):
            clip_params.append(p)
        else:
            head_params.append(p)

    param_groups = []
    if head_params:
        param_groups.append({"params": head_params, "lr": lr_head, "weight_decay": wd})
    if clip_params:
        param_groups.append({"params": clip_params, "lr": lr_clip, "weight_decay": wd})

    return torch.optim.AdamW(param_groups)


def build_cosine_warmup_scheduler(optimizer, total_steps, warmup_steps):
    def lr_lambda(step):
        if step < warmup_steps:
            return float(step) / float(max(1, warmup_steps))
        progress = float(step - warmup_steps) / float(max(1, total_steps - warmup_steps))
        return 0.5 * (1.0 + math.cos(math.pi * progress))
    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


# =========================
# train / eval
# =========================
def train_one_epoch(model, loader, optimizer, scheduler, processor, device):
    model.train()
    loss_meter = 0.0
    iou_meter = 0.0
    n = 0

    pbar = tqdm(loader, desc="Train", leave=False)
    for images, texts, masks in pbar:
        images = images.to(device)                # (B,3,H,W)
        masks = masks.to(device)                  # (B,1,H,W)

        # text -> processor（CLIP tokenizer）
        text_inputs = processor(text=list(texts),
                                return_tensors="pt",
                                padding=True,
                                truncation=True).to(device)

        logits = model(images, text_inputs)       # (B,1,H,W)

        bce = F.binary_cross_entropy_with_logits(logits, masks)
        dsc = dice_loss_with_logits(logits, masks)
        loss = bce + cfg.dice_weight * dsc

        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        if cfg.grad_clip is not None and cfg.grad_clip > 0:
            torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        optimizer.step()
        scheduler.step()

        with torch.no_grad():
            batch_iou = batch_iou_from_logits(logits, masks, thr=cfg.thr_eval)

        loss_meter += loss.item()
        iou_meter += batch_iou
        n += 1

        pbar.set_postfix(loss=loss_meter / n, iou=iou_meter / n)

    return loss_meter / max(1, n), iou_meter / max(1, n)


@torch.no_grad()
def eval_one_epoch(model, loader, processor, device):
    model.eval()
    loss_meter = 0.0
    iou_meter = 0.0
    n = 0

    pbar = tqdm(loader, desc="Val", leave=False)
    for images, texts, masks in pbar:
        images = images.to(device)
        masks = masks.to(device)

        text_inputs = processor(text=list(texts),
                                return_tensors="pt",
                                padding=True,
                                truncation=True).to(device)

        logits = model(images, text_inputs)

        bce = F.binary_cross_entropy_with_logits(logits, masks)
        dsc = dice_loss_with_logits(logits, masks)
        loss = bce + cfg.dice_weight * dsc

        batch_iou = batch_iou_from_logits(logits, masks, thr=cfg.thr_eval)

        loss_meter += loss.item()
        iou_meter += batch_iou
        n += 1

        pbar.set_postfix(loss=loss_meter / n, iou=iou_meter / n)

    return loss_meter / max(1, n), iou_meter / max(1, n)


def ensure_dir(path):
    os.makedirs(path, exist_ok=True)


def save_metrics_csv(path, rows):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["epoch", "train_loss", "train_iou", "val_loss", "val_iou", "lr_head", "lr_clip"])
        for r in rows:
            w.writerow(r)


def plot_curves(metrics_csv, out_png):
    # 可中斷後仍能畫圖
    import pandas as pd
    import matplotlib.pyplot as plt

    df = pd.read_csv(metrics_csv)
    plt.figure()
    plt.plot(df["epoch"], df["train_loss"], label="train_loss")
    plt.plot(df["epoch"], df["val_loss"], label="val_loss")
    plt.plot(df["epoch"], df["train_iou"], label="train_iou")
    plt.plot(df["epoch"], df["val_iou"], label="val_iou")
    plt.legend()
    plt.xlabel("epoch")
    plt.grid(True)
    plt.savefig(out_png, dpi=200, bbox_inches="tight")
    plt.close()


# =========================
# NEW: Top-K saver
# =========================
def _safe_iou_str(iou: float) -> str:
    # 0.1234 -> "0p1234"
    return f"{iou:.4f}".replace(".", "p")

def _topk_ckpt_path(output_dir: str, run_name: str, epoch: int, val_iou: float) -> str:
    return os.path.join(output_dir, f"{run_name}_ep{epoch:03d}_iou{_safe_iou_str(val_iou)}.pth")

def update_topk_checkpoints(topk_heap,  # min-heap of (val_iou, path)
                            model,
                            epoch: int,
                            val_iou: float,
                            k: int,
                            output_dir: str,
                            run_name: str):
    """
    只保留 top-k (val_iou 越大越好)。
    - 會在需要時儲存當前 epoch checkpoint
    - 超過 k 會刪掉最差的那個檔案
    """
    if k <= 0:
        return

    # 若還沒滿 k：一定存
    if len(topk_heap) < k:
        path = _topk_ckpt_path(output_dir, run_name, epoch, val_iou)
        torch.save(model.state_dict(), path)
        heapq.heappush(topk_heap, (val_iou, path))
        print(f"  ✓ saved topK ({len(topk_heap)}/{k}) -> {path}")
        return

    # 已滿 k：只有當 val_iou > 目前最小的那個 才更新
    min_iou, min_path = topk_heap[0]
    if val_iou > min_iou:
        path = _topk_ckpt_path(output_dir, run_name, epoch, val_iou)
        torch.save(model.state_dict(), path)
        heapq.heapreplace(topk_heap, (val_iou, path))
        # 刪掉被擠掉的
        try:
            if os.path.exists(min_path):
                os.remove(min_path)
        except Exception as e:
            print("[topK delete warning]", e)
        print(f"  ✓ saved topK (replaced {min_iou:.4f}) -> {path}")


def main():
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    ensure_dir(cfg.output_dir)

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print("device:", device)

    # datasets (albumentations already inside dataset.py)
    train_img_dir = os.path.join(cfg.img_dir, "train_images")
    val_img_dir   = os.path.join(cfg.img_dir, "val_images")

    train_ds = PhraseGroundingDataset(cfg.train_csv, train_img_dir,
                                      image_size=cfg.image_size,
                                      is_train=True, return_gt=True)
    val_ds = PhraseGroundingDataset(cfg.val_csv, val_img_dir,
                                    image_size=cfg.image_size,
                                    is_train=False, return_gt=True)

    train_loader = DataLoader(train_ds, batch_size=cfg.batch_size,
                              shuffle=True, num_workers=cfg.num_workers,
                              pin_memory=True, drop_last=True)

    val_loader = DataLoader(val_ds, batch_size=cfg.batch_size,
                            shuffle=False, num_workers=cfg.num_workers,
                            pin_memory=True, drop_last=False)

    # model
    model = CLIPUNet(image_size=cfg.image_size, freeze_clip=True).to(device)

    # processor
    processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch16")

    # 先 freeze CLIP（頭先學穩）
    set_clip_trainable(model, False)

    total_steps = cfg.epochs * len(train_loader)
    warmup_steps = int(total_steps * cfg.warmup_ratio)

    optimizer = build_optimizer(model, cfg.lr_head, cfg.lr_clip, cfg.weight_decay)
    scheduler = build_cosine_warmup_scheduler(optimizer, total_steps, warmup_steps)

    best_val_iou = -1.0
    best_path = os.path.join(cfg.output_dir, f"{cfg.run_name}.pth")
    last_path = os.path.join(cfg.output_dir, f"{cfg.run_name}_last.pth")
    metrics_path = os.path.join(cfg.output_dir, f"metrics_{cfg.run_name}.csv")
    curve_path = os.path.join(cfg.output_dir, f"loss_curve_{cfg.run_name}.png")

    metrics_rows = []

    # NEW: top-k heap
    topk_heap = []  # min-heap: (val_iou, path)

    start_time = time.time()

    try:
        for epoch in range(1, cfg.epochs + 1):
            # 解凍策略：第 freeze_epochs+1 個 epoch 開始解凍最後幾個 block
            if epoch == cfg.freeze_epochs + 1:
                print(f"[Unfreeze] last {cfg.unfreeze_last_blocks} CLIP vision blocks")
                unfreeze_clip_last_blocks(model, cfg.unfreeze_last_blocks)

                # 重新建 optimizer（把 clip 參數納入）
                optimizer = build_optimizer(model, cfg.lr_head, cfg.lr_clip, cfg.weight_decay)
                # scheduler 也重建（維持剩餘步數的 cosine）
                remain_steps = (cfg.epochs - epoch + 1) * len(train_loader)
                warmup2 = int(remain_steps * cfg.warmup_ratio)
                scheduler = build_cosine_warmup_scheduler(optimizer, remain_steps, warmup2)

            tr_loss, tr_iou = train_one_epoch(model, train_loader, optimizer, scheduler, processor, device)
            va_loss, va_iou = eval_one_epoch(model, val_loader, processor, device)

            # 取目前 lr（head/clip）
            lrs = [g["lr"] for g in optimizer.param_groups]
            lr_head = lrs[0] if len(lrs) > 0 else 0.0
            lr_clip = lrs[1] if len(lrs) > 1 else 0.0

            print(f"[Epoch {epoch:03d}] train loss={tr_loss:.4f} iou={tr_iou:.4f} | val loss={va_loss:.4f} iou={va_iou:.4f}")

            metrics_rows.append([epoch, tr_loss, tr_iou, va_loss, va_iou, lr_head, lr_clip])
            save_metrics_csv(metrics_path, metrics_rows)

            # always save last
            torch.save(model.state_dict(), last_path)

            # save best by val_iou
            if va_iou > best_val_iou:
                best_val_iou = va_iou
                torch.save(model.state_dict(), best_path)
                print(f"  ✓ saved best to {best_path} (val_iou={best_val_iou:.4f})")

            # NEW: save top-k by val_iou
            update_topk_checkpoints(topk_heap, model, epoch, va_iou, cfg.top_k, cfg.output_dir, cfg.run_name)

            # 每個 epoch 都嘗試畫（中斷也會有圖）
            try:
                plot_curves(metrics_path, curve_path)
            except Exception as e:
                print("[plot warning]", e)

    except KeyboardInterrupt:
        print("\n[Interrupted] saving last + plot...")

        torch.save(model.state_dict(), last_path)
        save_metrics_csv(metrics_path, metrics_rows)
        try:
            plot_curves(metrics_path, curve_path)
        except Exception as e:
            print("[plot warning]", e)

    elapsed = time.time() - start_time
    print(f"Training done. best_val_iou={best_val_iou:.4f} time={elapsed/60:.1f} min")
    print("best:", best_path)
    print("last:", last_path)
    print("metrics:", metrics_path)
    print("curve:", curve_path)

    # NEW: print top-k summary
    if cfg.top_k > 0 and len(topk_heap) > 0:
        top_sorted = sorted(topk_heap, key=lambda x: x[0], reverse=True)
        print(f"top{cfg.top_k} checkpoints:")
        for i, (iou, path) in enumerate(top_sorted, 1):
            print(f"  #{i}: iou={iou:.4f}  {path}")


if __name__ == "__main__":
    main()
