import os
import csv
import argparse
import numpy as np
import torch
from tqdm import tqdm
import cv2
import torchvision.transforms as transforms
from PIL import Image

from model import CLIPUNet
from transformers import CLIPProcessor

# CLIP normalize
CLIP_MEAN = (0.48145466, 0.4578275, 0.40821073)
CLIP_STD  = (0.26862954, 0.26130258, 0.27577711)

def mask_to_polygon(mask01: np.ndarray, use_morph=False, k=7, close_it=2, open_it=1, eps_scale=0.0) -> str:
    """
    mask01: uint8/bool, shape (H,W), values 0/1
    return polygon string: "[x1, y1, x2, y2, ...]" in ORIGINAL image coords
    """
    if mask01 is None:
        return "[]"

    mask = (mask01.astype(np.uint8) * 255)

    if use_morph:
        k = int(k)
        if k % 2 == 0:
            k += 1
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k))
        if close_it > 0:
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=int(close_it))
        if open_it > 0:
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=int(open_it))

    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return "[]"

    c = max(contours, key=cv2.contourArea)

    if eps_scale and eps_scale > 0:
        peri = cv2.arcLength(c, True)
        c = cv2.approxPolyDP(c, float(eps_scale) * peri, True)

    if c is None or len(c) < 3:
        return "[]"

    flat = c.reshape(-1).astype(np.float32).tolist()
    if len(flat) < 6 or (len(flat) % 2 != 0):
        return "[]"

    return "[" + ", ".join(f"{v:.1f}" for v in flat) + "]"

def get_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--img_dir", type=str, default="data/test_images")            # "data/test_images" or "data/train_images"
    parser.add_argument("--csv_path", type=str, default="data/test_samples.csv")      # "data/test_samples.csv" or "data/holdout.csv"
    parser.add_argument("--checkpoint", type=str, default="checkpoints/w_314605021.pth")
    parser.add_argument("--output_file", type=str, default="pred_314605021.csv")        # "pred_314605021.csv" or "pred_holdout.csv"
    parser.add_argument("--image_size", type=int, default=224)

    # post-process
    parser.add_argument("--thr", type=float, default=0.070)  # thr
    parser.add_argument("--use_morph", action="store_true")
    parser.add_argument("--morph_k", type=int, default=7)
    parser.add_argument("--morph_close", type=int, default=2)
    parser.add_argument("--morph_open", type=int, default=1)
    parser.add_argument("--eps_scale", type=float, default=0.0)

    # IMPORTANT：為了跟 TA 一致，預設不做 auto-drop
    parser.add_argument("--auto_drop_thr_if_empty", action="store_true")
    return parser.parse_args()

@torch.no_grad()
def main():
    args = get_args()
    device = "cuda" if torch.cuda.is_available() else "cpu"

    tfm = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor(),
        transforms.Normalize(CLIP_MEAN, CLIP_STD),
    ])

    model = CLIPUNet(image_size=args.image_size, freeze_clip=True).to(device)
    sd = torch.load(args.checkpoint, map_location=device)
    model.load_state_dict(sd, strict=True)
    model.eval()

    processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch16")

    # read csv (id,image,text, maybe segmentation)
    rows = []
    with open(args.csv_path, encoding="utf-8-sig", newline="") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append((row["id"], row["image"], row["text"]))

    print(f"img_dir    : {args.img_dir}")
    print(f"csv_path   : {args.csv_path} ({len(rows)} rows)")
    print(f"checkpoint : {args.checkpoint}")
    print(f"thr        : {args.thr}")
    print(f"morph      : {args.use_morph}")
    print(f"out        : {args.output_file}")

    with open(args.output_file, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["id", "image", "segmentation"])

        for sid, img_name, text in tqdm(rows, desc="Infer"):
            img_path = os.path.join(args.img_dir, img_name)
            bgr = cv2.imread(img_path)
            if bgr is None:
                w.writerow([sid, img_name, "[]"])
                continue
            h0, w0 = bgr.shape[:2]

            # to RGB then tensor
            rgb = cv2.cvtColor(bgr, cv2.COLOR_BGR2RGB)
            image_t = tfm(Image.fromarray(rgb)).unsqueeze(0).to(device)
            text_inputs = processor(
                text=[text],
                return_tensors="pt",
                padding=True,
                truncation=True
            ).to(device)

            logits = model(image_t, text_inputs)   # (1,1,224,224)
            prob = torch.sigmoid(logits)[0, 0].detach().cpu().numpy().astype(np.float32)

            # resize prob -> original size BEFORE threshold
            prob = cv2.resize(prob, (w0, h0), interpolation=cv2.INTER_LINEAR)

            thr = float(args.thr)
            mask01 = (prob > thr).astype(np.uint8)

            if args.auto_drop_thr_if_empty:
                while mask01.sum() == 0 and thr > 1e-6:
                    thr *= 0.5
                    mask01 = (prob > thr).astype(np.uint8)

            seg = mask_to_polygon(
                mask01,
                use_morph=args.use_morph,
                k=args.morph_k,
                close_it=args.morph_close,
                open_it=args.morph_open,
                eps_scale=args.eps_scale
            )
            w.writerow([sid, img_name, seg])

    print("Done.")

if __name__ == "__main__":
    main()
