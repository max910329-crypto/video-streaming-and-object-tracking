import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import CLIPModel


class CLIPUNet(nn.Module):
    """
    CLIP-based language-guided segmentation (improved fusion: Residual + Norm)
    """

    def __init__(self, image_size=224, freeze_clip=True):
        super().__init__()
        # You Shall Not modify the loaded model!
        self.clip = CLIPModel.from_pretrained("openai/clip-vit-base-patch16")
        self.image_size = image_size

        # freeze CLIP parameters
        if freeze_clip:
            for p in self.clip.parameters():
                p.requires_grad = False

        # CLIP: vision hidden=768, projection_dim=512
        dim = self.clip.config.projection_dim  # 512

        # --- Fusion: (vmap, vmap*tmap) -> 256 ---
        self.fuse_proj = nn.Conv2d(dim * 2, 256, kernel_size=1, bias=False)

        # GroupNorm: 對 batch size 不敏感（比 BatchNorm 更穩）
        # 256 channels 可用 32 groups（256/32=8 channels per group）
        self.fuse_norm1 = nn.GroupNorm(num_groups=32, num_channels=256)
        self.fuse_conv1 = nn.Conv2d(256, 256, kernel_size=3, padding=1, bias=False)

        self.fuse_norm2 = nn.GroupNorm(num_groups=32, num_channels=256)
        self.fuse_conv2 = nn.Conv2d(256, 256, kernel_size=3, padding=1, bias=False)

        self.act = nn.GELU()

        # decoder：把 14x14 upsample 回 image_size，最後吐 1 channel logits
        self.head = nn.Sequential(
            nn.Conv2d(256, 128, 3, padding=1), nn.GELU(),
            nn.Conv2d(128, 64, 3, padding=1), nn.GELU(),
            nn.Conv2d(64, 32, 3, padding=1), nn.GELU(),
            nn.Conv2d(32, 1, 1),
        )

    def forward(self, image, text_inputs):
        """
        image: (B,3,H,W) 已 normalize
        text_inputs: dict with input_ids, attention_mask
        return: logits (B,1,H,W)
        """
        B, _, H, W = image.shape

        # ---- vision patch tokens ----
        v = self.clip.vision_model(
            pixel_values=image,
            return_dict=True,
        ).last_hidden_state  # (B, 1+196, 768)

        v = v[:, 1:, :]  # drop CLS -> (B,196,768)
        v = self.clip.visual_projection(v)  # (B,196,512)
        vmap = v.transpose(1, 2).reshape(B, -1, 14, 14)  # (B,512,14,14)

        # ---- text vector ----
        tvec = self.clip.get_text_features(
            input_ids=text_inputs["input_ids"],
            attention_mask=text_inputs["attention_mask"]
        )  # (B,512)
        tmap = tvec[:, :, None, None].expand(-1, -1, 14, 14)  # (B,512,14,14)

        # ---- fuse (Residual + Norm) ----
        x = torch.cat([vmap, vmap * tmap], dim=1)  # (B,1024,14,14)

        x = self.fuse_proj(x)          # (B,256,14,14)
        res = x                        # residual branch

        x = self.fuse_norm1(x)
        x = self.act(x)
        x = self.fuse_conv1(x)

        x = self.fuse_norm2(x)
        x = self.act(x)
        x = self.fuse_conv2(x)

        x = x + res                    # residual add

        # upsample 回原圖大小
        x = F.interpolate(x, size=(H, W), mode="bilinear", align_corners=False)
        logits = self.head(x)          # (B,1,H,W)
        return logits
