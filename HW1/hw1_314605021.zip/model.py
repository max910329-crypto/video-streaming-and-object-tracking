# model.py
import torch
import torch.nn as nn
import math

def conv3x3(in_ch, out_ch, stride=1, groups=1, dilation=1):
    return nn.Conv2d(in_ch, out_ch, kernel_size=3, stride=stride, padding=1*dilation,
                     bias=False, groups=groups, dilation=dilation)

def conv1x1(in_ch, out_ch, stride=1):
    return nn.Conv2d(in_ch, out_ch, kernel_size=1, stride=stride, bias=False)

class BasicBlock(nn.Module):
    """ResNet BasicBlock（3x3 + 3x3），含可選的 downsample"""
    expansion = 1
    def __init__(self, in_ch, out_ch, stride=1, downsample=None, norm_layer=nn.BatchNorm2d, drop_path=0.0):
        super().__init__()
        self.conv1 = conv3x3(in_ch, out_ch, stride)
        self.bn1   = norm_layer(out_ch)
        self.relu  = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(out_ch, out_ch)
        self.bn2   = norm_layer(out_ch)
        self.downsample = downsample
        self.drop_path = drop_path

    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        out = out + identity
        out = self.relu(out)
        return out

class TinyResNet(nn.Module):
    def __init__(self, num_classes=100, depths=(1,1,1,1), width_mult=0.5, stem_channels=32, dropout=0.0,
                 block=BasicBlock, norm_layer=nn.BatchNorm2d):
        super().__init__()
        wm = width_mult

        # stem
        stem_out = int(round(stem_channels * wm))
        self.stem = nn.Sequential(
            nn.Conv2d(3, stem_out, kernel_size=3, stride=2, padding=1, bias=False),
            norm_layer(stem_out),
            nn.ReLU(inplace=True)
        )

        # 每個 stage 的目標通道（會被 width_mult 縮放）
        chs = [int(round(c * wm)) for c in (64, 128, 256, 512)]

        # 依 depths 動態建 stage（用 ModuleList 裝起來）
        self.stages = nn.ModuleList()
        in_ch = stem_out
        last_out = in_ch
        for s, (out_ch, d) in enumerate(zip(chs, depths)):
            if d <= 0:
                # 這個 stage 完全跳過
                self.stages.append(nn.Identity())
                continue
            # 第 0 個 stage 不降採樣，其餘 stage 的第一個 block stride=2
            stride = 1 if s == 0 else 2
            stage = self._make_layer(block, in_ch, out_ch, blocks=d, stride=stride, norm_layer=norm_layer)
            self.stages.append(stage)
            in_ch = out_ch * block.expansion
            last_out = in_ch

        self.pool = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(p=dropout) if dropout > 0 else nn.Identity()
        self.fc = nn.Linear(last_out, num_classes)

        self._init_weights()

    def _make_layer(self, block, in_ch, out_ch, blocks, stride, norm_layer):
        if blocks <= 0:
            # 保險：雖然 __init__ 已經處理過，這裡再防呆
            return nn.Identity()

        downsample = None
        if stride != 1 or in_ch != out_ch * block.expansion:
            downsample = nn.Sequential(
                conv1x1(in_ch, out_ch * block.expansion, stride),
                norm_layer(out_ch * block.expansion),
            )

        layers = []
        # 第一個 block（可能 stride=2 且需要 downsample）
        layers.append(block(in_ch, out_ch, stride=stride, downsample=downsample, norm_layer=norm_layer))
        # 後續 blocks（stride=1）
        for _ in range(1, blocks):
            layers.append(block(out_ch * block.expansion, out_ch, stride=1, downsample=None, norm_layer=norm_layer))
        return nn.Sequential(*layers)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            elif isinstance(m, (nn.BatchNorm2d, nn.GroupNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)


    def forward(self, x):
        x = self.stem(x)
        for stage in self.stages:
            x = stage(x)          # 跳過的 stage 是 Identity，不影響
        x = self.pool(x).flatten(1)
        x = self.dropout(x)
        x = self.fc(x)
        return x


class ClassificationModel(nn.Module):
    """
    你在 train/test 會匯入的類別。
    透過 width_mult / depths / stem_channels 控制參數量與性能。
    """
    def __init__(self, num_classes=100, width_mult=0.1, depths=(1,1,1,1), stem_channels=16, dropout=0.2):
        super().__init__()
        self.backbone = TinyResNet(
            num_classes=num_classes,
            depths=depths,
            width_mult=width_mult,
            stem_channels=stem_channels,
            dropout=dropout,
        )

    def forward(self, x):
        return self.backbone(x)
