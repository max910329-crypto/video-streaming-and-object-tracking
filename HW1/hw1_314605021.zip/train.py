import os, sys, json, random, time
import torch, torch.nn as nn, torch.optim as optim
from torch.utils.data import DataLoader, SubsetRandomSampler
from torchvision import datasets, transforms
from model import ClassificationModel
from tqdm.auto import tqdm
import wandb

# --------------------- Utilities ---------------------
def get_env(name, default=None, cast=str):
    v = os.getenv(name, None)
    if v is None:
        return default
    try:
        return cast(v)
    except Exception:
        return default

IS_TTY = sys.stdout.isatty()
FORCE_TQDM = get_env("FORCE_TQDM", "0") == "1"
DISABLE_BAR = False if FORCE_TQDM else (not IS_TTY)
def tprint(msg): tqdm.write(str(msg))

# --------------------- Config ---------------------
STUDENT_ID   = "314605021"
DATA_ROOT    = "./dataset/train"
VAL_RATIO    = 0.1
SPLIT_FILE   = f"split_{STUDENT_ID}.json"
SEED         = 42
USE_ALL      = True

EPOCHS       = get_env("EPOCHS", 60, int)
BATCH_SIZE   = get_env("BATCH_SIZE", 64, int)
LR           = get_env("LR", 3e-4, float)
WEIGHT_DECAY = get_env("WEIGHT_DECAY", 5e-4, float)
NUM_WORKERS  = get_env("NUM_WORKERS", 4, int)
PATIENCE     = get_env("PATIENCE", 5, int)
WATCH_GRADS  = get_env("WATCH_GRADS", "0") == "1"
LOG_ARTIFACTS= get_env("LOG_ARTIFACTS", "0") == "1"

width_mult     = get_env("WIDTH", 0.1, float)
depths         = tuple(map(int, get_env("DEPTH", "1,1,1,1").split(",")))
stem_channels  = get_env("STEM", 16, int)
dropout        = get_env("DROPOUT", 0.2, float)

# --------------------- Helper ---------------------
def stratified_split_indices(targets, val_ratio=0.1, seed=42, ensure_min_train_val=True):
    random.seed(seed)
    from collections import defaultdict
    by_cls = defaultdict(list)
    for i, y in enumerate(targets):
        by_cls[int(y)].append(i)

    train_idx, val_idx, warns = [], [], []
    for cls, idxs in by_cls.items():
        random.shuffle(idxs)
        n = len(idxs)
        k = max(1, int(round(n * val_ratio)))
        if ensure_min_train_val:
            if n == 1:
                warns.append(f"[warn] class {cls} has only 1 image -> put in TRAIN only")
                train_idx.extend(idxs)
                continue
            if k >= n: k = n - 1
            if k < 1:  k = 1
        val_idx.extend(idxs[:k])
        train_idx.extend(idxs[k:])
    return train_idx, val_idx, warns

# --------------------- Train ---------------------
def train():
    random.seed(SEED)
    torch.manual_seed(SEED)
    torch.cuda.manual_seed_all(SEED)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    run = wandb.init(
        project="vsot-hw1",
        name=STUDENT_ID,
        mode=os.getenv("WANDB_MODE", "online"),
        config={
            "student_id": STUDENT_ID,
            "use_all": USE_ALL,
            "batch_size": BATCH_SIZE,
            "lr": LR,
            "epochs": EPOCHS,
        },
    )

    train_tf = transforms.Compose([
        transforms.RandomResizedCrop(224, scale=(0.8, 1.0)),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ])
    val_tf = transforms.Compose([
        transforms.Resize(256),
        transforms.CenterCrop(224),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
    ])

    full_train = datasets.ImageFolder(DATA_ROOT, transform=train_tf)
    full_val   = datasets.ImageFolder(DATA_ROOT, transform=val_tf)

    # dataset split
    if USE_ALL:
        train_idx = list(range(len(full_train)))
        val_idx = []
        train_loader = DataLoader(full_train, batch_size=BATCH_SIZE,
                                  sampler=SubsetRandomSampler(train_idx),
                                  num_workers=NUM_WORKERS, pin_memory=True)
        val_loader = None
    else:
        train_idx, val_idx, _ = stratified_split_indices(full_train.targets, VAL_RATIO, SEED)
        train_loader = DataLoader(full_train, batch_size=BATCH_SIZE,
                                  sampler=SubsetRandomSampler(train_idx),
                                  num_workers=NUM_WORKERS, pin_memory=True)
        val_loader = DataLoader(full_val, batch_size=BATCH_SIZE,
                                sampler=SubsetRandomSampler(val_idx),
                                num_workers=NUM_WORKERS, pin_memory=True)

    model = ClassificationModel(
        num_classes=len(full_train.classes),
        width_mult=width_mult,
        depths=depths,
        stem_channels=stem_channels,
        dropout=dropout,
    ).to(device)

    print(f"width_mult={width_mult}, depths={depths}, stem={stem_channels}, dropout={dropout}")
    total_params = sum(p.numel() for p in model.parameters())
    print(f"# parameters: {total_params:,d} ({total_params/1e6:.2f} M)")

    wandb.config.update({
        "width_mult": width_mult,
        "depths": depths,
        "stem_channels": stem_channels,
        "dropout": dropout,
        "num_params": total_params,
    })

    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='max', factor=0.5, patience=2)

    best_val_top5 = 0.0
    no_improve = 0

    for epoch in range(EPOCHS):
        model.train()
        running_loss = 0.0
        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/{EPOCHS} [Train]", dynamic_ncols=True)
        for imgs, labels in pbar:
            imgs, labels = imgs.to(device), labels.to(device)
            logits = model(imgs)
            loss = criterion(logits, labels)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * imgs.size(0)

        train_loss = running_loss / len(train_idx)
        val_top1 = val_top5 = 0.0

        if val_loader is not None:
            model.eval()
            tot1 = tot5 = cnt = 0
            with torch.no_grad():
                for imgs, labels in val_loader:
                    imgs, labels = imgs.to(device), labels.to(device)
                    logits = model(imgs)
                    pred1 = logits.argmax(dim=1)
                    tot1 += (pred1 == labels).float().sum().item()
                    _, pred5 = logits.topk(5, dim=1)
                    tot5 += pred5.eq(labels.view(-1,1)).any(dim=1).float().sum().item()
                    cnt += labels.size(0)
            val_top1 = tot1 / cnt
            val_top5 = tot5 / cnt
            scheduler.step(val_top5)
        else:
            scheduler.step(train_loss)

        wandb.log({
            "epoch": epoch + 1,
            "train/loss": train_loss,
            "val/top1": val_top1,
            "val/top5": val_top5,
        })

        # Save best or final model
        if val_loader is not None:
            if val_top5 > best_val_top5:
                best_val_top5 = val_top5
                torch.save(model.state_dict(), f"w_{STUDENT_ID}.pth")
                tprint(f"[info] saved best weights (val@5={val_top5:.3f})")
        else:
            # 全資料訓練時，每 10 epoch 存一次 or 最後一次
            if (epoch+1) % 10 == 0 or epoch == EPOCHS - 1:
                torch.save(model.state_dict(), f"w_{STUDENT_ID}_final.pth")
                tprint(f"[info] saved model checkpoint at epoch {epoch+1}")

    wandb.finish()

if __name__ == "__main__":
    # USE_ALL=1 → 全資料重訓
    # FORCE_TQDM=1 WANDB_MODE=offline python -u train.py
    train()
