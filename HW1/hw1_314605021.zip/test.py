# test.py
import os, csv, json
import torch
from PIL import Image
from torchvision import transforms
from model import ClassificationModel

STUDENT_ID = "314605021"

# 助教會改這個路徑，指到 hidden test dataset
# 你本地測試時改成自己的測試資料夾就好
DATAPATH = r"./dataset/test"

# ==== 載入訓練時存下的類別順序 ====
with open(f"classes_{STUDENT_ID}.json", "r", encoding="utf-8") as f:
    CLASSES = json.load(f)  # list[str], 長度=100

# ==== 前處理（與 val 的相同） ====
# 為什麼要一致？確保測試分布跟訓練時 val 一樣，結果才穩定
tf = transforms.Compose([
    transforms.Resize(256),
    transforms.CenterCrop(224),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485,0.456,0.406], std=[0.229,0.224,0.225]),
])

def load_image(path):
    img = Image.open(path).convert("RGB")
    return tf(img).unsqueeze(0)  # [1,3,224,224]

def test():
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 建立模型並載入訓練好的權重
    model = ClassificationModel(num_classes=len(CLASSES)).to(device)
    state = torch.load(f"w_{STUDENT_ID}.pth", map_location=device)
    model.load_state_dict(state, strict=True)
    model.eval()

    # 讀取所有測試圖片檔名
    img_files = sorted([f for f in os.listdir(DATAPATH) if f.lower().endswith((".jpg",".jpeg",".png"))])

    # 開 CSV 檔寫入結果
    with torch.no_grad(), open(f"pred_{STUDENT_ID}.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        # 表頭要跟 example.csv 一模一樣
        writer.writerow(["file_name","pred1","pred2","pred3","pred4","pred5"])

        for name in img_files:
            x = load_image(os.path.join(DATAPATH, name)).to(device)
            logits = model(x)               # [1,100]
            _, idx = logits.topk(5, dim=1)  # [1,5] → 取分數最高的前 5 類
            labels = [CLASSES[i] for i in idx[0].tolist()]  # 把索引轉成類別名稱
            writer.writerow([name] + labels)  # 輸出一列：檔名 + 五個預測類別

    print(f"[info] wrote predictions to pred_{STUDENT_ID}.csv")

if __name__ == "__main__":
    test()
